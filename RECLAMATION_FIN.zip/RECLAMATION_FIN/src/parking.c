#include"parking.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int ajouter_avis(char*filename , Review R)
{
   FILE * f=fopen("reclamation.txt","a");
    if(f!=NULL)
     {
       fprintf(f,"%s %s %s %s %d %d %d %d \n",R.category,R.comment,R.statue,R.review_ID,R.note,R.dateR.jour,R.dateR.mois,R.dateR.annee);	       
       fclose(f);
	return 1;            
     }
   else return 0;
}

int modifier_avis(char*filename,char* cn, Review Rn)
{  int trouve=0;
   Review R;
   FILE * f=fopen("reclamation.txt","r");
   FILE * f1=fopen("reclamation_temp.txt","w");
   if(f!=NULL || f1!=NULL)
   {
       while(fscanf(f,"%s %s %s %s %d %d %d %d \n",R.category,R.comment,R.statue,R.review_ID,&R.note,&R.dateR.jour,&R.dateR.mois,&R.dateR.annee)!=EOF)
       { 
 	if(strcmp(R.review_ID,cn)==0 );
	 {
             fprintf(f1,"%s %s %s %s %d %d %d %d \n",R.category,R.comment,R.statue,R.review_ID,R.note,R.dateR.jour,R.dateR.mois,R.dateR.annee);
             trouve =1;
          } 
      }
   }
   fclose(f);
   fclose(f1);
   remove("reclamation.txt");
   rename("reclamation_temp.txt","reclamation.txt");
   return trouve; 
}
int supprimer_avis(char*filename,char*id)
{  int trouve=0;
   Review R1;
   FILE * f=fopen(filename,"r");
   FILE * f1=fopen("reclamation_temp.txt","w");
   if(f!=NULL && f1!=NULL)
   {
       while(fscanf(f,"%s %s %s %d %s %s\n",R1.city,R1.id_parking,R1.comment,&R1.note,R1.category,R1.statue)!=EOF)
       { 
 	 if(strcmp(R1.id_parking,id)==0 )
	 {
            trouve=1;;
          }
	  else 
	      fprintf(f1,"%s %s %s %d %s %s\n",R1.city,R1.id_parking,R1.comment,R1.note,R1.category,R1.statue);	  
      }
   }
   fclose(f);
   fclose(f1);
   remove(filename);
   rename("Rn.txt",filename);
   return trouve;

}

float calculer_moyenne(Review reviews[], int count, char* id_parking) {
    int total_notes = 0;
    int nb_notes = 0;
    float s;
    for (int i = 0; i < count; i++) {
        if (strcmp(reviews[i].id_parking, id_parking) == 0) {
            total_notes += reviews[i].note;
            nb_notes++;
        }
    }
    
    if (nb_notes == 0) return 0;  // Eviter la division par 0
    s = total_notes / nb_notes;
    return s;
}
// Fonction principale de tri des avis par moyenne des notes
int tri_avis(char* filename, Review reviews[], ParkingAvg parkings[], int* num_parkings, float min_note) {
    FILE *f = fopen(filename, "r");
    if (f == NULL) {
        return -1; // Erreur d'ouverture du fichier
    }

    int count = 0;
    while (fscanf(f, "%s %s %s %d %s %s\n", reviews[count].city, reviews[count].id_parking, reviews[count].comment, &reviews[count].note,reviews[count].category,reviews[count].statue) != EOF) {
        count++;
    }
    fclose(f);

    // Remplir le tableau des parkings avec leurs moyennes
    *num_parkings = 0;
    for (int i = 0; i < count; i++) {
        int found = 0;
        for (int j = 0; j < *num_parkings; j++) {
            if (strcmp(parkings[j].id_parking, reviews[i].id_parking) == 0) {
                found = 1;
                break;
            }
        }
        
        if (!found) {
            strcpy(parkings[*num_parkings].id_parking, reviews[i].id_parking);
            parkings[*num_parkings].moy_feedback = calculer_moyenne(reviews, count, reviews[i].id_parking);
            (*num_parkings)++;
        }
    }

    // Tri des parkings par moyenne décroissante
    for (int i = 0; i < *num_parkings - 1; i++) {
        for (int j = i + 1; j < *num_parkings; j++) {
            if (parkings[i].moy_feedback < parkings[j].moy_feedback) {
                ParkingAvg temp = parkings[i];
                parkings[i] = parkings[j];
                parkings[j] = temp;
            }
        }
    }

    return 0;
}


