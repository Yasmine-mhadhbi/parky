#ifndef PARKING_H_INCLUDED
#define PARKING_H_INCLUDED
typedef struct {
    int jour;
    int mois;
    int annee;  
}Date;
typedef struct
{
	char comment[200];
	int note;
	char category[20];
	char statue[50];
        char review_ID[30];
	Date dateR;
}Review;

typedef struct { 
	char id_parking[20]; 
	char location[100]; 
	int totalSpaces; 
	int availableSpaces; 
	float price; 
	int state; 
	char state_text[20]; 
	Date openingDate; 	
	int spforCars; 
	int spforMotorcycles; 
	int spforTrucks; 
	char types[100]; 
} Parking;
typedef struct {
    char id_parking[20];
    float moy_feedback;  
} ParkingAvg;


int ajouter_avis(char* , Review);
int modifier_avis(char*, char*, Review);  
int supprimer_avis(char* , char*);
int tri_avis(char* filename, Review reviews[], ParkingAvg parkings[], int* num_parkings, float min_note);
float calculer_moyenne(Review reviews[], int count, char* id_parking);
#endif


