#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdbool.h>
#include "parking.h"

Review R, Rm;
Parking P;


GtkWidget * ANONYMOS_ADD;
GtkWidget * REALNAME_ADD;
GtkWidget * ANONYMOS_UPDATE;
GtkWidget * REALNAME_UPDATE;
GtkWidget * COMPLIMENT;
GtkWidget * COMPLAINT;


void
on_ADD_WELCOME_REC_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1")); 
gtk_notebook_set_current_page(notebook, 1);

}


void
on_DISPLAY_WELCOME_REC_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1")); 
gtk_notebook_set_current_page(notebook, 4);

}


void
on_ACTIVITY_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1")); 
gtk_notebook_set_current_page(notebook, 5);

}


void
on_RETURN_WELCOME_REC_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_DELETE_WELCOME_REC_clicked          (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1")); 
gtk_notebook_set_current_page(notebook, 3);

}


void
on_UPDATE_WELCOME_REC_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1")); 
gtk_notebook_set_current_page(notebook, 2);

}


void
on_ANONYMOS_ADD_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ANONYMOS_ADD)))
   strcpy(R.statue, "Anonymos");
}


void
on_REALNAME_ADD_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(REALNAME_ADD)))
   strcpy(R.statue, "Realname");
}


void
on_SUBMIT_clicked                      (GtkWidget      *button,
                                        gpointer         user_data)
{
int j, m, a;
char id_to_findR[20];
GtkWidget * entry1;//Text entry pour le commentaire
GtkWidget * entry2;//label pour entrer review id 
GtkWidget * spinbutton1; //spinbtton1 pour la note
GtkWidget * category;//combobox pour choisir la categorie
GtkWidget * calendar1;//calendrier pour entrer la date d'ajout
GtkWidget * ANONYMOS_ADD;
GtkWidget * REALNAME_ADD;
GtkWidget *entry6 = lookup_widget(button, "entry6");//label pour entrer parking id 
GtkWidget *ID_PARKING_ADD = lookup_widget(button, "ID_PARKING_ADD");
 
entry1=lookup_widget(button,"entry1");
entry2=lookup_widget(button,"entry2");
spinbutton1=lookup_widget(button, "spinbutton1");
category=lookup_widget(button,"category");
calendar1=lookup_widget(button,"calendar1");
ANONYMOS_ADD=lookup_widget(button,"ANONYMOS_ADD");
REALNAME_ADD=lookup_widget(button,"REALNAME_ADD");

strcpy(id_to_findR, gtk_entry_get_text(GTK_ENTRY(entry6)));
strcpy(R.comment,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(R.review_ID,gtk_entry_get_text(GTK_ENTRY(entry2)));
R.note=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));

if(strcmp("Complaint",gtk_combo_box_get_active_text(GTK_COMBO_BOX(category)))==0)
strcpy(R.category, "Complaint");
else
strcpy(R.category, "Compliment");

if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ANONYMOS_ADD)))
   strcpy(R.statue, "Anonymos");
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(REALNAME_ADD)))
   strcpy(R.statue, "Realname");

gtk_calendar_get_date(GTK_CALENDAR(calendar1), &j, &m, &a);
R.dateR.jour = j;
R.dateR.mois = m + 1 ;
R.dateR.annee = a;


FILE *f=fopen("reclamation.txt","a");
GtkWidget *dialog;
if(f == NULL){
printf("ERROR: COULD NOT OPEN THE FILE \n");
dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "ERROR: COULD NOT OPEN THE FILE.");
}
else
{
fprintf(f,"%s %s %s %s %s %d %d %d %d \n",P.id_parking,R.review_ID,R.category,R.comment,R.statue,R.note,R.dateR.jour,R.dateR.mois,R.dateR.annee);
printf("Review added successfully \n");
dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_INFO,
                                        GTK_BUTTONS_OK,
                                        "Review added successfully !");
}
fclose(f);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}


void
on_CANCEL_clicked                      (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
    notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1"));
    gtk_notebook_set_current_page(notebook, 0);
}


void
on_SAVE_REC_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
int j, m, a,found = 0;
GtkWidget * entry3;//Text entry pour taper le nouveau commentaire
GtkWidget * spinbutton2; //spinbtton2 pour la note
GtkWidget * entry5;//entry5 pour chercher review_id a modifier
GtkWidget * calendar2;//calendrier pour entrer la date de modification
GtkWidget * ANONYMOS_UPDATE;
GtkWidget * REALNAME_UPDATE;
GtkWidget * COMPLIMENT;
GtkWidget * COMPLAINT;
GtkWidget *label_REVIEW_UPDATE = lookup_widget(button, "label_REVIEW_UPDATE");

entry3=lookup_widget(button,"entry3");
spinbutton2=lookup_widget(button, "spinbutton2");
entry5=lookup_widget(button,"entry5");
calendar2=lookup_widget(button,"calendar2");
ANONYMOS_UPDATE=lookup_widget(button,"ANONYMOS_UPDATE");
REALNAME_UPDATE=lookup_widget(button,"REALNAME_UPDATE");
COMPLIMENT=lookup_widget(button,"COMPLIMENT");
COMPLAINT=lookup_widget(button,"COMPLAINT");


strcpy(Rm.comment,gtk_entry_get_text(GTK_ENTRY(entry3)));
Rm.note=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));

gtk_calendar_get_date(GTK_CALENDAR(calendar2), &j, &m, &a);
Rm.dateR.jour = j;
Rm.dateR.mois = m + 1 ;
Rm.dateR.annee = a;

if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ANONYMOS_UPDATE)))
   strcpy(Rm.statue, "Anonymos");
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(REALNAME_UPDATE)))
   strcpy(Rm.statue, "Realname");
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(COMPLIMENT)))  
   strcpy(Rm.category, "Compliment"); 
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(COMPLAINT)))  
   strcpy(Rm.category, "Complaint"); 


FILE *f=fopen("reclamation.txt","r");
FILE *f_temp=fopen("reclamation_temp.txt","W");
GtkWidget *dialog;
if(f != NULL && f_temp!= NULL){
while(fscanf(f,"%s %s %s %s %s %d %d %d \n",P.id_parking,Rm.review_ID,Rm.category,Rm.comment,Rm.statue,&Rm.dateR.jour,&Rm.dateR.mois,&Rm.dateR.annee)!=EOF){
if (strcmp(Rm.review_ID, R.review_ID) == 0) {
found = 1;
fprintf(f_temp,"%s %s %s %s %s %d %d %d \n",P.id_parking,R.category,R.comment,R.statue,R.review_ID,&R.dateR.jour,&R.dateR.mois,&R.dateR.annee);
}else{
fprintf(f_temp,"%s %s %s %s %s %d %d %d \n",P.id_parking,Rm.category,Rm.comment,Rm.statue,Rm.review_ID,&Rm.dateR.jour,&Rm.dateR.mois,&Rm.dateR.annee);}}
fclose(f);
fclose(f_temp);
if (found) {
remove("reclamation.txt");
rename("reclamtion_temp.txt","reclamation.txt");
printf("Review modified successfully\n");
gtk_label_set_text(GTK_LABEL(label_REVIEW_UPDATE), "Review modified successfully.");
dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_INFO,
                                        GTK_BUTTONS_OK,
                                        "Review added successfully !");
} else {
printf("Review not found\n");
gtk_label_set_text(GTK_LABEL(label_REVIEW_UPDATE), "Review not found.");
dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "ERROR");}  
} 
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}


void
on_CANCEL_UPDATE_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
    notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1"));
    gtk_notebook_set_current_page(notebook, 0);
}


void
on_ANONYMOS_UPDATE_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ANONYMOS_UPDATE)))
   strcpy(Rm.statue, "Anonymos");
}


void
on_REALNAME_UPDATE_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(REALNAME_UPDATE)))
   strcpy(Rm.statue, "Realname");
}



void
on_COMPLIMENT_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if(gtk_toggle_button_get_active(togglebutton)) {
        strcpy(Rm.category, "Compliment");
    }
}


void
on_COMPLAINT_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if(gtk_toggle_button_get_active(togglebutton)){
        strcpy(Rm.category, "Complaint");
    }
}


void
on_CANCEL_DELETE_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
    notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1"));
    gtk_notebook_set_current_page(notebook, 0);
}


void
on_DISCARD_REC_clicked                 (GtkWidget      *button,
                                        gpointer         user_data)
{
Review Rs;
char id_to_findR[20];
char line[256];
int found = 0;

GtkWidget *entry4 = lookup_widget(button, "entry4");
GtkWidget *label_review_D = lookup_widget(button, "label_review_D");
strcpy(id_to_findR, gtk_entry_get_text(GTK_ENTRY(entry4)));

FILE *f = fopen("reclamation.txt", "r");
FILE *temp_file = fopen("Rec_temp.txt", "w"); 
GtkWidget *dialog;   
if(f == NULL || temp_file == NULL) {
gtk_label_set_text(GTK_LABEL(label_review_D), "Error opening files.");
dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_ERROR,
                                        GTK_BUTTONS_OK,
                                        "ERROR: COULD NOT OPEN THE FILE.");
return;
}
 while (fscanf(f,"%s %s %s %s %s %d %d %d \n",P.id_parking,Rs.category,Rs.comment,Rs.statue,Rs.review_ID,&Rs.dateR.jour,&Rs.dateR.mois,&Rs.dateR.annee)!=EOF) {
if (strcmp(id_to_findR, Rs.review_ID) == 0) {
found = 1;
}else{
fprintf(temp_file,"%s %s %s %s %s %d %d %d \n",P.id_parking,Rs.category,Rs.comment,Rs.statue,Rs.review_ID,Rs.dateR.jour,Rs.dateR.mois,Rs.dateR.annee);
}
}
fclose(f);
fclose(temp_file);
if (found) {
remove("reclamation.txt");
rename("Rec_temp.txt", "reclamation.txt");
gtk_label_set_text(GTK_LABEL(label_review_D), "Review deleted successfully.");
dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(button))),
                                        GTK_DIALOG_DESTROY_WITH_PARENT,
                                        GTK_MESSAGE_INFO,
                                        GTK_BUTTONS_OK,
                                        "Review deleted successfully !");
}else {
remove("Rec_temp.txt");
gtk_label_set_text(GTK_LABEL(label_review_D), "Review not found.");
}
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}



void
on_SEARCH_REC_clicked                  (GtkWidget      *button,
                                        gpointer         user_data)
{
    char id_to_findR[20];
    bool found = FALSE;
   
    GtkWidget *label_review_D = lookup_widget(button, "label_review_D");
    GtkWidget *entry4 = lookup_widget(button, "entry4");
    strcpy(id_to_findR, gtk_entry_get_text(GTK_ENTRY(entry4)));

     FILE *f = fopen("reclamation.txt", "r");
    if (f == NULL) {
        gtk_label_set_text(GTK_LABEL(label_review_D), "Error: Cannot open file");
        return;
    }

    while (fscanf(f,"%s %s %s %s %s %d %d %d \n",P.id_parking,R.review_ID,R.category,R.comment,R.statue,&R.dateR.jour,&R.dateR.mois,&R.dateR.annee)!=EOF){
        if (strcmp(id_to_findR, R.review_ID) == 0) {
            found = TRUE;
        }
    }
    fclose(f);

    if (found) {
        gtk_label_set_text(GTK_LABEL(label_review_D), "Review found");
	GtkWidget *DISCARD_REC_button = lookup_widget(button, "DISCARD_REC");
	if(DISCARD_REC_button)
            gtk_widget_set_sensitive(DISCARD_REC_button, TRUE);
    } else {
        gtk_label_set_text(GTK_LABEL(label_review_D), "Review not found");
	GtkWidget *DISCARD_REC_button = lookup_widget(button, "DISCARD_REC");
        if(DISCARD_REC_button)
            gtk_widget_set_sensitive(DISCARD_REC_button, FALSE);
    }
    gtk_widget_show(label_review_D);



}


/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

void
on_REFRESH_ACTIVITY_REC_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_REFRESH_DISPLAY_REC_clicked         (GtkWidget      *button,
                                        gpointer         user_data)
{

}*/


void
on_VIEW_DISPLAY_REC_clicked            (GtkWidget      *button,
                                        gpointer         user_data)
{
   GtkWidget *treeview;    
    GtkListStore *store;    
    GtkTreeIter iter;    
    GtkCellRenderer *renderer;    
    GtkTreeViewColumn *column;    
    FILE *f;    
 
    // S'assurer que le widget est correctement récupéré
    treeview = lookup_widget(button, "treeview_display");
    if (!treeview) {
        g_print("Error: Could not find treeview widget\n");
        return;
    }

    // Supprimer les anciennes colonnes si elles existent
    GList *columns = gtk_tree_view_get_columns(GTK_TREE_VIEW(treeview));
    while (columns) {
        gtk_tree_view_remove_column(GTK_TREE_VIEW(treeview), columns->data);
        columns = g_list_next(columns);
    }
    g_list_free(columns);

    // Créer le renderer une seule fois
    renderer = gtk_cell_renderer_text_new();

    // Créer les colonnes
    column = gtk_tree_view_column_new_with_attributes("ID Parking", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Note", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
    // Créer le nouveau store
    store = gtk_list_store_new(2, 
                              G_TYPE_STRING,  // ID Parking
                              G_TYPE_INT); //note

    // Ouvrir et lire le fichier
    f = fopen("reclamation.txt", "r");    
    if (f == NULL) {
        g_print("Error: Cannot open file reclamation.txt\n");
        return;
    }

    // Lire et ajouter chaque ligne
    while (fscanf(f, "%s %d\n", 
                 P.id_parking,
                 R.note 
                 != EOF)) {  

        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, P.id_parking,
                          1, R.note,
                         -1);
    }
    fclose(f);

    // Définir le modèle et s'assurer que le treeview est visible
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    gtk_widget_show_all(treeview);
    g_object_unref(store);

    // Debuggage
    g_print("Treeview updated with data\n");
}


void
on_VIEW_ACTIVITY_REC_clicked           (GtkWidget      *button,
                                        gpointer         user_data)
{

    GtkWidget *treeview;    
    GtkListStore *store;    
    GtkTreeIter iter;    
    GtkCellRenderer *renderer;    
    GtkTreeViewColumn *column;    
    FILE *f;    
    
    // S'assurer que le widget est correctement récupéré
    treeview = lookup_widget(button, "treeview_activity");
    if (!treeview) {
        g_print("Error: Could not find treeview widget\n");
        return;
    }

    // Supprimer les anciennes colonnes si elles existent
    GList *columns = gtk_tree_view_get_columns(GTK_TREE_VIEW(treeview));
    while (columns) {
        gtk_tree_view_remove_column(GTK_TREE_VIEW(treeview), columns->data);
        columns = g_list_next(columns);
    }
    g_list_free(columns);

    // Créer le renderer une seule fois
    renderer = gtk_cell_renderer_text_new();

    // Créer les colonnes
    column = gtk_tree_view_column_new_with_attributes("ID Parking", renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("ID Review", renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Category", renderer, "text", 2, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Comment", renderer, "text", 3, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Status", renderer, "text", 4, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Note", renderer, "text", 5, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Year", renderer, "text", 6, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Month", renderer, "text", 7, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    column = gtk_tree_view_column_new_with_attributes("Day", renderer, "text", 8, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

    // Créer le nouveau store
    store = gtk_list_store_new(9, 
                              G_TYPE_STRING,  // ID Parking
                              G_TYPE_STRING,  // ID Review
                              G_TYPE_STRING,  // Category
                              G_TYPE_STRING,  // Comment
                              G_TYPE_STRING,  // Status
                              G_TYPE_INT,     // Note
                              G_TYPE_INT,     // Year
                              G_TYPE_INT,     // Month
                              G_TYPE_INT);    // Day

    // Ouvrir et lire le fichier
    f = fopen("reclamation.txt", "r");    
    if (f == NULL) {
        g_print("Error: Cannot open file reclamation.txt\n");
        return;
    }

    // Lire et ajouter chaque ligne
    while (fscanf(f, "%s %s %s %s %s %d %d %d %d\n", 
                 P.id_parking,
                 R.review_ID, 
                 R.category,
                 R.comment,
                 R.statue,
                 &R.note,
                 &R.dateR.jour,
                 &R.dateR.mois,
                 &R.dateR.annee) != EOF) {  

        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter,
                          0, P.id_parking,
                          1, R.review_ID,
                          2, R.category,
                          3, R.comment,
                          4, R.statue,
                          5, R.note,
                          6, R.dateR.annee,
                          7, R.dateR.mois,
                          8, R.dateR.jour,
                          -1);
    }
    fclose(f);

    // Définir le modèle et s'assurer que le treeview est visible
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    gtk_widget_show_all(treeview);
    g_object_unref(store);

    // Debuggage
    g_print("Treeview updated with data\n");

}


void
on_SEARCH_UPDATE_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
    char id_to_findR[20];
    bool found = FALSE;
   
    GtkWidget *label_REVIEW_UPDATE = lookup_widget(button, "label_REVIEW_UPDATE");
    GtkWidget *entry5 = lookup_widget(button, "entry5");
    strcpy(id_to_findR, gtk_entry_get_text(GTK_ENTRY(entry5)));

   

   FILE *f = fopen("reclamation.txt", "r");
    if (f == NULL) {
        gtk_label_set_text(GTK_LABEL(label_REVIEW_UPDATE), "Error: Cannot open file");
        return;
    }

    while (fscanf(f,"%s %s %s %s %s %d %d %d \n",P.id_parking,R.category,R.comment,R.statue,R.review_ID,&R.dateR.jour,&R.dateR.mois,&R.dateR.annee)!=EOF){
        if (strcmp(id_to_findR, R.review_ID) == 0) {
            found = TRUE;
        }
    }
    fclose(f);

    if (found) {
        gtk_label_set_text(GTK_LABEL(label_REVIEW_UPDATE), "Review found");
	GtkWidget *SAVE_REC_button = lookup_widget(button, "SAVE_REC");
	if(SAVE_REC_button)
            gtk_widget_set_sensitive(SAVE_REC_button, TRUE);
    } else {
        gtk_label_set_text(GTK_LABEL(label_REVIEW_UPDATE), "Review not found");
        gtk_entry_set_text(GTK_ENTRY(entry5), "");
	GtkWidget *SAVE_REC_button = lookup_widget(button, "SAVE_REC");
        if(SAVE_REC_button)
            gtk_widget_set_sensitive(SAVE_REC_button, FALSE);
    }
    gtk_widget_show(label_REVIEW_UPDATE);

}


void
on_SEARCH_ID_PARKING_ADD_clicked       (GtkWidget       *button,
                                        gpointer         user_data)
{

    char id_to_findR[20];
    bool found = FALSE;
    
    GtkWidget *ID_PARKING_ADD = lookup_widget(button, "ID_PARKING_ADD");
    GtkWidget *entry6 = lookup_widget(button, "entry6");
    strcpy(id_to_findR, gtk_entry_get_text(GTK_ENTRY(entry6)));

    FILE *f = fopen("parking.txt", "r");
    if (f == NULL) {
        gtk_label_set_text(GTK_LABEL(ID_PARKING_ADD), "Error: Cannot open file");
        return;
    }

    while (fscanf(f,"%s %s %s %s %s %d %d %d \n",P.id_parking,R.category,R.comment,R.statue,R.review_ID,&R.dateR.jour,&R.dateR.mois,&R.dateR.annee)!=EOF){
        if (strcmp(id_to_findR, P.id_parking) == 0) {
            found = TRUE;
        }
    }
    fclose(f);

    if (found) {
        gtk_label_set_text(GTK_LABEL(ID_PARKING_ADD), "Parking found");
	GtkWidget *submit_button = lookup_widget(button, "SUBMIT_REC");
	if(submit_button){
            gtk_widget_set_sensitive(submit_button, TRUE);
	} else {
        gtk_label_set_text(GTK_LABEL(ID_PARKING_ADD), "Parking not found");
	GtkWidget *submit_button = lookup_widget(button, "SUBMIT_REC");}
        if(submit_button){
            gtk_widget_set_sensitive(submit_button, FALSE);
    }
    gtk_widget_show(ID_PARKING_ADD);
}
}



void
on_CANCEL_DISPLAY_REC_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
    notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1"));
    gtk_notebook_set_current_page(notebook, 0);
}


void
on_CANCEL_ACTIVITY_REC_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook *notebook; 
    notebook = GTK_NOTEBOOK(lookup_widget(GTK_WIDGET(button), "notebook1"));
    gtk_notebook_set_current_page(notebook, 0);
}

