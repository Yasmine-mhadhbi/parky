#include <gtk/gtk.h>


void
on_ADD_WELCOME_REC_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_DISPLAY_WELCOME_REC_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ACTIVITY_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_RETURN_WELCOME_REC_clicked          (GtkWidget      *button,
                                        gpointer         user_data);

void
on_DELETE_WELCOME_REC_clicked          (GtkWidget      *button,
                                        gpointer         user_data);

void
on_UPDATE_WELCOME_REC_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ANONYMOS_ADD_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_REALNAME_ADD_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_SUBMIT_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CANCEL_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_SAVE_REC_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CANCEL_UPDATE_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ANONYMOS_UPDATE_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_REALNAME_UPDATE_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_COMPLIMENT_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_COMPLAINT_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_CANCEL_DELETE_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_DISCARD_REC_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_SEARCH_REC_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_REFRESH_ACTIVITY_REC_clicked        (GtkWidget      *button,
                                        gpointer         user_data);

void
on_REFRESH_DISPLAY_REC_clicked         (GtkWidget      *button,
                                        gpointer         user_data);

void
on_VIEW_DISPLAY_REC_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_VIEW_ACTIVITY_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_SEARCH_UPDATE_REC_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_SEARCH_ID_PARKING_ADD_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CANCEL_DISPLAY_REC_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_CANCEL_ACTIVITY_REC_clicked         (GtkButton       *button,
                                        gpointer         user_data);
